package com.example.employess_program

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
